<div class="modal fade" id="createModal" tabindex="-1" role="dialog" aria-labelledby="createModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createModalLabel">Создание записи</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
               <form>
                    <label for="search_name" class="form-label">Наименование</label>
                    <input type="text" class="form-control" id="search_name">
                </div>
                <div class="col-md">
                    <label for="search_admin_district" class="form-label">Административный округ</label>
                    <select class="form-control" id="search_admin_district">
                        <option value="">Не выбрано</option>
                        <option>Округ 1</option>
                        <option>Округ 2</option>
                        <option>Округ 3</option>
                    </select>
                </div>
                <div class="col-md">
                    <label for="search_district" class="form-label">Район</label>
                    <select class="form-control" id="search_district">
                        <option value="">Не выбрано</option>
                        <option>Район 1</option>
                        <option>Район 2</option>
                        <option>Район 3</option>
                    </select>
                </div>
                    <label for="search_object_type" class="form-label">Вид объекта</label>
                    <select class="form-control" id="search_object_type">
                        <option value="">Не выбрано</option>
                        <option>Вид 1</option>
                        <option>Вид 2</option>
                        <option>Вид 3</option>
                    </select>
                    <label for="search_is_chain" class="form-label">Является сетевым</label>
                    <select class="form-control" id="search_is_chain">
                        <option value="">Не выбрано</option>
                        <option>Да</option>
                        <option>Нет</option>
                    </select>
                    <label for="search_benefits" class="form-label">Льготы</label>
                    <select class="form-control" id="search_benefits">
                        <option value="">Не выбрано</option>
                        <option>Льгота 1</option>
                        <option>Льгота 2</option>
                        <option>Льгота 3</option>
                    </select>
                    <label for="search_seating_lower_limit" class="form-label">Количество посадочных мест (от)</label>
                    <input type="number" class="form-control" id="search_seating_lower_limit">
                    <label for="search_seating_upper_limit" class="form-label">Количество посадочных мест (до)</label>
                    <input type="number" class="form-control" id="search_seating_upper_limit">
                    <label for="search_date_from" class="form-label">Дата создания (с)</label>
                    <input type="date" class="form-control" id="search_date_from">
                    <label for="search_date_to" class="form-label">Дата создания (по)</label>
                    <input type="date" class="form-control" id="search_date_to">
            <div class="modal-footer">
                <button type="button" class="btn btn-primary">Сохранить</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
            </div>
        </div>
    </div>
</div>