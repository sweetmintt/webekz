<?php
// Необходимые настройки для подключения к базе данных
$db_host = 'localhost';
$db_name = 'tvorozhok5';
$db_user = 'tvorozhok5';
$db_pass = 'Polina2810';

// Создание соединения с базой данных
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Проверка соединения
if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}
?>