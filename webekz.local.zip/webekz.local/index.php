<!DOCTYPE html>
<html>
<head>
    <title>Административная панель</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css">
    <style>
        .footer {
            background-color: #81d4fa;
            padding: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-info">
        <div class="container">
            <a class="navbar-brand" href="#">Административная панель</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#createModal">Создать запись</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    Успешное выполнение операции!
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        </div>

        <h1 class="mt-4">Административная панель</h1>

        <form>
             <form>
            <div class="row mt-4">
                <div class="col-md">
                    <label for="search_name" class="form-label">Наименование</label>
                    <input type="text" class="form-control" id="search_name">
                </div>
                <div class="col-md">
                    <label for="search_admin_district" class="form-label">Административный округ</label>
                    <select class="form-control" id="search_admin_district">
                        <option value="">Не выбрано</option>
                        <option>Округ 1</option>
                        <option>Округ 2</option>
                        <option>Округ 3</option>
                    </select>
                </div>
                <div class="col-md">
                    <label for="search_district" class="form-label">Район</label>
                    <select class="form-control" id="search_district">
                        <option value="">Не выбрано</option>
                        <option>Район 1</option>
                        <option>Район 2</option>
                        <option>Район 3</option>
                    </select>
                </div>
                <div class="col-md">
                    <label for="search_object_type" class="form-label">Вид объекта</label>
                    <select class="form-control" id="search_object_type">
                        <option value="">Не выбрано</option>
                        <option>Вид 1</option>
                        <option>Вид 2</option>
                        <option>Вид 3</option>
                    </select>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-md">
                    <label for="search_is_chain" class="form-label">Является сетевым</label>
                    <select class="form-control" id="search_is_chain">
                        <option value="">Не выбрано</option>
                        <option>Да</option>
                        <option>Нет</option>
                    </select>
                </div>
                <div class="col-md">
                    <label for="search_benefits" class="form-label">Льготы</label>
                    <select class="form-control" id="search_benefits">
                        <option value="">Не выбрано</option>
                        <option>Льгота 1</option>
                        <option>Льгота 2</option>
                        <option>Льгота 3</option>
                    </select>
                </div>
                <div class="col-md">
                    <label for="search_seating_lower_limit" class="form-label">Количество посадочных мест (от)</label>
                    <input type="number" class="form-control" id="search_seating_lower_limit">
                </div>
                <div class="col-md">
                    <label for="search_seating_upper_limit" class="form-label">Количество посадочных мест (до)</label>
                    <input type="number" class="form-control" id="search_seating_upper_limit">
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md">
                    <label for="search_date_from" class="form-label">Дата создания (с)</label>
                    <input type="date" class="form-control" id="search_date_from">
                </div>
                <div class="col-md">
                    <label for="search_date_to" class="form-label">Дата создания (по)</label>
                    <input type="date" class="form-control" id="search_date_to">
                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <button type="submit" class="btn btn-primary">Найти</button>
                </div>
            </div>
        </form>


        <!-- Таблица с результатами поиска -->
        <table class="table mt-4">
            <thead>
                    <th>Наименование</th>
                    <th>Вид</th>
                    <th>Адрес</th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php include 'show_data.php'; ?>
            </tbody>
        </table>
    </div>

    <!-- Модальное окно для редактирования записи -->
    <?php include 'edit_modal.php'; ?>

    <!-- Модальное окно для подтверждения удаления записи -->
    <?php include 'delete_modal.php'; ?>

   <!-- Модальное окно для создания записи -->
    <?php include 'create_modal.php'; ?>
    
    <!-- Модальное окно для просмотра записи -->
<div class="modal fade" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="viewModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewModalLabel">Просмотр записи</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
            </div>
        </div>
    </div>
</div>
</form>

    <footer class="footer">
        <div class="container">
            <p class="text-muted">Данные предоставлены компанией, предлагающей информацию о предприятиях общественного питания города Москвы. Контакты: email@example.com</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>