<?
include 'db.php';
include 'edit_modal.php'; 
include 'delete_modal.php'; 

// Запрос для получения данных из таблицы
$sql = "SELECT * FROM enterprises LIMIT 11"; 

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["Name"]. "</td>";
        echo "<td>" . $row["TypeObject"]. "</td>";
        echo "<td>" . $row["Address"]. "</td>";
        
        echo '<td><button class="btn btn-primary" data-toggle="modal" data-target="#editModal' . $row["id"] . '">Редактировать</button></td>';
        echo '<td><button class="btn btn-danger delete-btn" data-toggle="modal" data-target="#deleteModal' . $row["id"] . '" data-id="' . $row["id"] .'">Удалить</button></td>';

        
        echo "</tr>";

        // Создаем модальное окно редактирования для каждой записи
        include 'edit_modal.php'; 
        // Создаем модальное окно удаления для каждой записи
        include 'delete_modal.php'; 
    }
} else {
    echo "<tr>";
    echo '<td colspan="5">Таблица пуста</td>';
    echo "</tr>";
}

$conn->close();
?>

<script>
$(document).ready(function(){
    // Обработчик клика по кнопке "Да" в модальном окне удаления
    $('.delete-btn').click(function(){
        var id = $(this).data('id');
        
        // Отправляем AJAX запрос на сервер для удаления записи
        $.ajax({
            url: 'delete.php',
            method: 'POST',
            data: {id: id},
            success: function(response){
                // Если операция удаления выполнена успешно
                if(response == 'success'){
                    // Удаляем соответствующую строку из таблицы
                    $('#row'+id).remove();
                    
                    // Показываем уведомление об успешном удалении
                    toastr.success('Запись успешно удалена');
                }
            }
        });
        
        // Закрываем модальное окно
        $('#deleteModal'+id).modal('hide');
    });
});
</script>