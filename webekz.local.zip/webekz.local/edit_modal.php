<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Редактирование записи</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form>
                    <input type="hidden" id="record_id">

                    <div class="mb-3">
                        <label for="edit_name" class="form-label">Наименование</label>
                        <input type="text" class="form-control" id="edit_name">
                    </div>
                    <div class="mb-3">
                        <label for="edit_type_object" class="form-label">Вид объекта</label>
                        <input type="text" class="form-control" id="edit_type_object">
                    </div>
                    <div class="mb-3">
                        <label for="edit_address" class="form-label">Адрес</label>
                        <input type="text" class="form-control" id="edit_address">
                    </div>
                    <div class="mb-3">
                        <label for="edit_description" class="form-label">Описание</label>
                        <textarea class="form-control" id="edit_description" rows="3"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary">Сохранить</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
            </div>
        </div>
    </div>
</div>